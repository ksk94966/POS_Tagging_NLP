Path should be given as follows:

Question 1: 

python <file name> NLP6320_POSTaggedTrainingSet-Windows.txt  "John went to work ."

(Example :  python Nb.py NLP6320_POSTaggedTrainingSet-Windows.txt  "John went to work .")


file names( <file name>)

1. Nb.py

-------------------------------------------------------------------------------------------------------------

Question 2:

python <file name>  "Janet will back the bill"

(Example :  python Viterbi_HMMDecoding_NLP.py "Janet will back the bill")


file names( <file name>)

1.  Viterbi_HMMDecoding_NLP.py


----------------------------------------------------------------------------------------------------------------